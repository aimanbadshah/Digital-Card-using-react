import React from 'react';
import FacebookLogo from './Facebook Logo.jpeg';
import InstagramLogo from './Instagram Logo.jpeg';
import XLogo from './X Logo.png';
import GitHubLogo from './GitHub Logo.png';

export default function Footer() {
    return (
        <div className="footer-container">
            <footer className="footer">
                <img src={XLogo} alt='X' className="social-icon" />
                <img src={InstagramLogo} alt='Instagram' className="social-icon" />
                <img src={FacebookLogo} alt='Facebook' className="social-icon" />
                <img src={GitHubLogo} alt='GitHub' className="social-icon" />
            </footer>
        </div>
    );
}
