import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Info from './Info.js';
import About from './About.js';
import Interests from './Interests.js';
import Footer from './Footer.js';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <React.StrictMode>
        <Info />
        <About />
        <Interests />
        <Footer />
    </React.StrictMode>
);
