import React from 'react';

export default function Interests() {
    return (
        <div className="section-container">
            <h4>Interests</h4>
            <p style={{padding: '0 0 10px 0'}}>Travelling, adventures, food, religion, photography, coding,
                learning new human as well as programming languages, book reading, crochet, sketching.</p>
        </div>
    );
}
