import React from 'react';

export default function About() {
    return (
        <div className="section-container">
            <h4>About</h4>
            <p>I am a computer engineer with interest in Artificial Intelligence. I like to solve critical problems
                which require logical thinking and am always looking for new opportunities to learn new things.</p>
        </div>
    );
}
