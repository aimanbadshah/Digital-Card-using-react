import React from 'react'
import './index.css'
import Image from './image.jpg'  

export default function Info() {
  return (
    <div className='info-card'> 
      <div>
        <img src={Image} alt="pfp"/>
        <h2>Aiman Badshah</h2>
        <h5>Computer Engineer</h5>
      </div>
      <div className="button-container"> 
        <button>Email</button>
        <button>LinkedIn</button>
      </div>
    </div>
  )
}